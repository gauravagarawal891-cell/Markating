# YourBrand Marketing Agency Website

A dark, bold, full-service marketing agency website.

## Files
- `index.html` — Main HTML structure
- `styles.css` — All styling (dark theme)
- `script.js` — Animations + form handler

---

## How to Run

### Option 1: VS Code (Live Server)
1. Open the `marketing-agency-website` folder in VS Code
2. Install the **Live Server** extension (by Ritwick Dey)
3. Right-click `index.html` → **Open with Live Server**
4. Opens at `http://127.0.0.1:5500`

### Option 2: Direct Browser
1. Just double-click `index.html`
2. Opens directly in your browser (no server needed)

### Option 3: Python (if installed)
```bash
cd marketing-agency-website
python -m http.server 3000
```
Then open `http://localhost:3000`

### Option 4: Node.js
```bash
cd marketing-agency-website
npx serve .
```

---

## Customization Checklist
- [ ] Replace `YourBrand` with your company name (in `index.html` — line 13, nav logo, footer)
- [ ] Update email: `hello@yourbrand.com`
- [ ] Update phone: `+91 98765 43210`
- [ ] Adjust pricing if needed (search `₹` in `index.html`)
- [ ] Update stats in Hero section (50+ clients, 3x ROI, etc.)

---

Built with HTML, CSS, JavaScript. No frameworks needed.
